window.ok( true, "evaluated: inner module with src" );
